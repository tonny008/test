﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPITest.Controllers
{
    public class BoxPlotController : ApiController
    {
        // GET api/<controller>
        public IEnumerable<object> Get()
        {
            List<object> list = new List<object>();
            var pool = WebAPITest.Controllers.VppDataController.Pool;
            var conn = pool.GetObject();
            var cmd = conn.CreateCommand();
            cmd.CommandText = @"select MEASURE_VL, ETESTER_ID, wafer_lot from usage_dev.ELECJ_POC_VPP a, usage_dev.ELECJ_POC_WAFER b
where a.war_id=b.wafer_rc and wafer_lot in(
SELECT wafer_lot FROM usage_dev.ELECJ_POC_WAFER group by wafer_lot order by max(pn_dm) desc limit 2) order by a.pn_dm desc";

            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    list.Add(new object[] { reader[1], reader[2], reader[0] });
                }
            }
            pool.PutObject(conn);
            return list.ToArray();
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}