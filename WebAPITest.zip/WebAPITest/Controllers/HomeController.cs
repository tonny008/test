﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAPITest.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.Title = "Home Page";
            List<SelectListItem> list = GetList(@"SELECT wafer_id FROM usage_dev.ELECJ_POC_WAFER group by wafer_id order by max(pn_dm) desc, wafer_id");
            list.Insert(0, new SelectListItem() { Text = "=Select Wafer=", Value = "" });
            ViewData["WaferList"] = list;
            list = GetList(@"SELECT wafer_lot FROM usage_dev.ELECJ_POC_WAFER group by wafer_lot order by max(pn_dm) desc, wafer_lot");
            list.Insert(0, new SelectListItem() { Text = "=Select Lot=", Value = "" });
            ViewData["LotList"] = list;

            return View();
        }

        private static List<SelectListItem> GetList(string sql)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            var pool = WebAPITest.Controllers.VppDataController.Pool;
            var conn = pool.GetObject();
            var cmd = conn.CreateCommand();
            cmd.CommandText = sql;

            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    list.Add(new SelectListItem() { Text = reader.GetString(0) });
                }
            }
            pool.PutObject(conn);
            return list;
        }
        public ActionResult BoxPlot()
        {
            ViewBag.Title = "box plot Page";

            return View();
        }
    }
}
