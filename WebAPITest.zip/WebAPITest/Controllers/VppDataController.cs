﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Vertica.Data.VerticaClient;

namespace WebAPITest.Controllers
{
    public class VppDataController : ApiController
    {
        public class ObjectPool<T> : IDisposable where T : IDisposable
        {
            private ConcurrentBag<T> _objects;
            private Func<T> _objectGenerator;

            public ObjectPool(Func<T> objectGenerator)
            {
                if (objectGenerator == null) throw new ArgumentNullException("objectGenerator");
                _objects = new ConcurrentBag<T>();
                _objectGenerator = objectGenerator;
            }

            public T GetObject()
            {
                T item;
                if (_objects.TryTake(out item)) return item;
                return _objectGenerator();
            }

            public void PutObject(T item)
            {
                _objects.Add(item);
            }

            public void Dispose()
            {
                if (_objects != null)
                {
                    foreach (T item in _objects)
                    {
                        item.Dispose();
                    }
                    _objects = null;
                }
            }
        }

        static ObjectPool<VerticaConnection> pool;
        public static ObjectPool<VerticaConnection> Pool
        {
            get
            {
                if (pool == null)
                {
                    pool = new ObjectPool<VerticaConnection>(() =>
                {
                    VerticaConnection _conn = new VerticaConnection("Host=shr2-vrt-dev-vglb1.houston.hp.com;Database=shr1_vrt_dev;User=svc_usage_dev;Port=5433;Password=Usage_dev_2013!;Pooling=True;");
                    _conn.Open();
                    return _conn;
                }
                );
                }
                return pool;
            }
        }
        // GET api/<controller>
        public IEnumerable<Series> Get()
        {
            Stopwatch sw = Stopwatch.StartNew();
            //VerticaConnectionStringBuilder builder = new VerticaConnectionStringBuilder();
            //builder.Host = "shr2-vrt-dev-vglb1.houston.hp.com";
            //builder.Database = "shr1_vrt_dev";
            //builder.User = "svc_usage_dev";
            //builder.Port = 5433;
            //builder.Password = "Usage_dev_2013!";

            //string strConn = builder.ToString() + ";Pooling=true;";
            var conn = Pool.GetObject();
            Debug.WriteLine(sw.Elapsed);
            var cmd = conn.CreateCommand();
            cmd.CommandText = "select PN_DM, MEASURE_VL, ETESTER_ID, WAR_ID  from usage_dev.ELECJ_POC_VPP order by PN_DM desc limit 100";
            //cmd.CommandText = "select PN_DM, MEASURE_VL, ETESTER_ID, PN_ID, DIE_SITE_NR from usage_dev.ELECJ_POC_VPP order by PN_DM desc limit 100";
            List<Series> re = new List<Series>();
            using (var reader = cmd.ExecuteReader())
            {
                Dictionary<string, List<object[]>> dict = new Dictionary<string, List<object[]>>();

                System.TimeSpan span = new System.TimeSpan(System.DateTime.Parse("1/1/1970").Ticks);
                long minStamp = long.MaxValue, maxStamp = long.MinValue;
                while (reader.Read())
                {
                    string eTest = reader.GetString(2);
                    if (!dict.ContainsKey(eTest))
                    {
                        dict.Add(eTest, new List<object[]>());
                    }
                    long timestamp = (long)(reader.GetDateTime(0).Subtract(span).Ticks / 10000);
                    if (timestamp < minStamp)
                    {
                        minStamp = timestamp;
                    }
                    if (timestamp > maxStamp)
                    {
                        maxStamp = timestamp;
                    }
                    dict[eTest].Add(new object[] { timestamp, reader[1], reader[3] });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(1), 1.2F });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(2), 1.3F });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(3), 1.5F });

                }
                re.Add(new Series() { color = "red", data = new object[] { new object[] { minStamp, .5 }, new object[] { maxStamp, .5 } } });
                re.Add(new Series() { color = "red", data = new object[] { new object[] { minStamp, -.5 }, new object[] { maxStamp, -.5 } } });
                foreach (var item in dict.Keys)
                {
                    Series s = new Series();
                    s.label = item;
                    s.data = dict[item].ToArray();
                    re.Add(s);
                }

            }
            Pool.PutObject(conn);
            sw.Stop();
            Debug.WriteLine(sw.Elapsed);
            return re;
        }

        // GET api/<controller>/5
        public IEnumerable<Series> Get(int id)
        {
            var conn = Pool.GetObject();

            var cmd = conn.CreateCommand();
            cmd.CommandText = @"select a.PN_ID, a.ETESTER_ID,  a.WAR_ID, a.MEASURE_VL 
from usage_dev.ELECJ_POC_VPP a inner join 
(select PN_ID, ETESTER_ID,  WAR_ID, max(PN_DM) MaxDM  
        from usage_dev.ELECJ_POC_VPP group by PN_ID, ETESTER_ID, WAR_ID) b 
        on a.PN_ID=b.PN_ID and a.ETESTER_ID=b.ETESTER_ID
        and a.WAR_ID=b.WAR_ID and a.PN_DM=b.MaxDM
order by a.PN_DM desc limit 100";
            //cmd.CommandText = "select PN_DM, MEASURE_VL, ETESTER_ID, PN_ID, DIE_SITE_NR from usage_dev.ELECJ_POC_VPP order by PN_DM desc limit 100";
            List<Series> re = new List<Series>();
            using (var reader = cmd.ExecuteReader())
            {
                Dictionary<string, List<object[]>> dict = new Dictionary<string, List<object[]>>();

                System.TimeSpan span = new System.TimeSpan(System.DateTime.Parse("1/1/1970").Ticks);
                string firstPnId = null, lastPnId = null;
                List<string> pnIdList = new List<string>();
                while (reader.Read())
                {
                    string eTest = reader.GetString(1);
                    if (!dict.ContainsKey(eTest))
                    {
                        dict.Add(eTest, new List<object[]>());
                    }
                    var pnId = reader.GetString(0);
                    if (firstPnId == null) firstPnId = pnId;
                    lastPnId = pnId;
                    int index = pnIdList.IndexOf(pnId);
                    if (index == -1)
                    {
                        index = pnIdList.Count;
                        pnIdList.Add(pnId);
                    }
                    dict[eTest].Add(new object[] { index, reader[3], reader[2], pnId });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(1), 1.2F });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(2), 1.3F });
                    //list.Add(new object[] { DateTime.Now.AddMinutes(3), 1.5F });

                }
                re.Add(new Series() { color = "red", data = new object[] { new object[] { pnIdList.IndexOf(firstPnId), .5 }, new object[] { pnIdList.IndexOf(lastPnId), .5 } } });
                re.Add(new Series() { color = "red", data = new object[] { new object[] { pnIdList.IndexOf(firstPnId), -.5 }, new object[] { pnIdList.IndexOf(lastPnId), -.5 } } });
                foreach (var item in dict.Keys)
                {
                    Series s = new Series();
                    s.label = item;
                    s.data = dict[item].ToArray();
                    re.Add(s);
                }

            }
            Pool.PutObject(conn);
            return re;
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }

    public class Series
    {
        public string color { get; set; }
        public string label { get; set; }

        public object[] data { get; set; }
    }
}